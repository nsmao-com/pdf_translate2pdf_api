"""
FastAPI 测试服务器（演示版）
这个版本用于测试 API 结构，不执行实际的 PDF 翻译
"""

from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import io

app = FastAPI(
    title="PDFMathTranslate API (Demo)",
    description="Lightweight REST API for PDF translation - Demo Version",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class HealthResponse(BaseModel):
    status: str
    version: str
    service: str
    mode: str

SUPPORTED_SERVICES = [
    "google", "bing", "deepl", "deeplx", "deepseek",
    "ollama", "openai", "azure-openai", "gemini",
    "zhipu", "silicon", "groq", "grok"
]

SUPPORTED_LANGUAGES = [
    "zh", "en", "ja", "ko", "es", "fr", "de", "ru",
    "pt", "it", "ar", "hi"
]

@app.get("/", response_model=HealthResponse)
async def root():
    """根路径 - 健康检查"""
    return HealthResponse(
        status="healthy",
        version="1.0.0",
        service="PDFMathTranslate API",
        mode="demo"
    )

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """健康检查端点"""
    return HealthResponse(
        status="healthy",
        version="1.0.0",
        service="PDFMathTranslate API",
        mode="demo"
    )

@app.get("/services")
async def list_services():
    """获取支持的翻译服务列表"""
    return {
        "services": SUPPORTED_SERVICES,
        "note": "Demo mode - actual translation not available"
    }

@app.get("/languages")
async def list_languages():
    """获取支持的语言列表"""
    return {
        "languages": SUPPORTED_LANGUAGES,
        "note": "Use ISO 639-1 language codes"
    }

@app.post("/translate/mono")
async def translate_mono(
    file: UploadFile = File(...),
    lang_in: str = Form("en"),
    lang_out: str = Form("zh"),
    service: str = Form("google"),
    thread: int = Form(4)
):
    """翻译 PDF（单语版本）- 演示模式"""

    # 验证文件
    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")

    # 验证语言
    if lang_in not in SUPPORTED_LANGUAGES:
        raise HTTPException(status_code=400, detail=f"Unsupported source language: {lang_in}")
    if lang_out not in SUPPORTED_LANGUAGES:
        raise HTTPException(status_code=400, detail=f"Unsupported target language: {lang_out}")

    # 验证服务
    service_base = service.split(':')[0].lower()
    if service_base not in SUPPORTED_SERVICES:
        raise HTTPException(status_code=400, detail=f"Unsupported service: {service}")

    # 读取文件信息
    content = await file.read()
    file_size = len(content)

    return JSONResponse({
        "status": "demo_mode",
        "message": "This is a demo API. Actual translation requires full pdf2zh installation.",
        "request_info": {
            "filename": file.filename,
            "file_size_bytes": file_size,
            "lang_in": lang_in,
            "lang_out": lang_out,
            "service": service,
            "thread": thread
        },
        "note": "In production, this endpoint would return the translated PDF file"
    })

@app.post("/translate/dual")
async def translate_dual(
    file: UploadFile = File(...),
    lang_in: str = Form("en"),
    lang_out: str = Form("zh"),
    service: str = Form("google"),
    thread: int = Form(4)
):
    """翻译 PDF（双语版本）- 演示模式"""

    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")

    content = await file.read()
    file_size = len(content)

    return JSONResponse({
        "status": "demo_mode",
        "message": "This is a demo API. Actual translation requires full pdf2zh installation.",
        "request_info": {
            "filename": file.filename,
            "file_size_bytes": file_size,
            "lang_in": lang_in,
            "lang_out": lang_out,
            "service": service,
            "thread": thread
        },
        "note": "In production, this endpoint would return the bilingual PDF file"
    })

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.detail, "status_code": exc.status_code}
    )

if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*60)
    print("PDFMathTranslate FastAPI Demo Server")
    print("="*60)
    print("\n启动信息:")
    print("  - 服务地址: http://localhost:8000")
    print("  - API 文档: http://localhost:8000/docs")
    print("  - ReDoc: http://localhost:8000/redoc")
    print("\n注意: 这是演示版本，不执行实际的 PDF 翻译")
    print("     完整功能需要安装 pdf2zh 及其依赖\n")
    print("="*60 + "\n")

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )
